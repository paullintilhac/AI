#!/bin/bash

g++ -std=gnu++11 -o hw3.out *.cpp

./hw3.out testData.txt
