#!/bin/bash

g++ -o hw4.exe prog4.cpp

./hw4.exe tinyCorpus.txt smallCorpus.txt stopWords.txt
