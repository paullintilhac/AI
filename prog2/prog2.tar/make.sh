#!/bin/bash

g++ -std=gnu++11 -o driver.exe driver.cpp

./driver.exe mazefile
