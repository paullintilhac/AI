#!/bin/bash

g++ -o driver.exe driver.cpp

./driver.exe mazefile
